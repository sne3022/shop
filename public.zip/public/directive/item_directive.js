var mallDirective = angular.module('mallDirective', ["ui.bootstrap",]);
mallDirective.$inject = ["$element", "baseUrl", "$document", "mallfactory", "optionfactory"];

mallDirective.controller("Ctrl", function($scope){
	$scope.show="list";
	$scope.total_price =0; //장바구니 총가격
	$scope.total_quantity =1; //장바구니 총 수량
	$scope.list=[]; //장바구니 담을 배열 리스트
	$scope.itemNumber = 0; //장바구니 상품 구분번호
	$scope.currentPage = 1; //현재 페이지 값 
})


/* 상품 목록 PAGE */
mallDirective.directive('itemList', function(baseUrl, $document, mallfactory, optionfactory){
	return {
		restrict: 'E',
		templateUrl: baseUrl+'template/list.html',
		link: function(scope, element, attr){

			scope.totalItemNumber = 0; //상품 총개수 초기화
    		scope.itemperpage = 3; //페이지당 상품 표시 개수
    		getItems(); //상품 가져오기 
    		scope.items =[]; //상품을 담는 공간

    		/* 상품 가져오기 Pagination */
    		function getItems()
		    {   
		    	/* 상품 가져오는 쿼리문 */ 
		        mallfactory.query().$promise.then(function(result)
		        { 
			        scope.totalItemNumber = result.length; //아이탬 총 개수
			        scope.items = result; 
			        scope.currentPage = scope.$parent.currentPage;
			        scope.startItem = (scope.$parent.currentPage -1) * scope.itemperpage;
			        scope.endItem = scope.startItem + scope.itemperpage;
			        scope.totalItems = scope.items.slice(scope.startItem, scope.endItem);   
		        })
		    }

		    /* 페이지 번호 이동 Pagination  */
		    scope.pageChanged = function() 
    		{   
		        scope.startItem = (scope.currentPage -1) * scope.itemperpage;  
		        scope.endItem = scope.startItem + scope. itemperpage; 
		        scope.totalItems = scope.items.slice(scope.startItem, scope.endItem) 
		    }

		    /* 상품 자세히 */
			scope.detail = function(item_code) 
			{	
				scope.$parent.currentPage = scope.currentPage; //현재 페이지 쪽 정보
				scope.$parent.show ="detail";
				scope.$parent.code = item_code;
			}

			/* 상품 장바구니 이동*/
			scope.pocketList = function()
			{
				scope.$parent.show ="pocket";
			}
		}
	}
})


/* 상품 자세히 PAGE */
mallDirective.directive('itemDetail', function(baseUrl, $document, mallfactory, optionfactory){
	return {
		restrict: 'E',
		templateUrl: baseUrl+'template/detail.html',
		link: function(scope, element, attr, Ctrl){
			scope.optionList = []; //상품 옵션을 담을 공간
			scope.user={
				size:"옵션을 선택해주세요"
			};
			

			/* 해당 상품 데이터 가져오기 */ 
			mallfactory.get({id:scope.$parent.code}).$promise.then(function(result)
			{					
					scope.item = result; //전체 상품 정보
					scope.code = scope.item.p_code; //상품 코드

					scope.sImg = []; //작은 이미지 정보 담을 공간
					scope.bImg = scope.item.p_big_img; //큰 이미지 정보

					scope.quantity =1; //수량 초기값
					scope.totalQuantity = scope.item.p_quantity; //상품 수량

					scope.title = scope.item.p_title; //상품 타이틀
					scope.price = scope.item.p_price; //상품 가격
	
					scope.origin_price = scope.item.p_price; //상품 기본 가격

					/* 작은 이미지 정보 (,) 기준 나눠 담기 */
					var str = scope.item.p_small_img;
					if(str != null)
					scope.sImg = str.split(",");
			});

			/* 세자리 기준 단위 (,) 표시 */
			function comma()
			{
				$(".price").each(function(){
					$(this).html( Number(a[0]).toLocaleString().split('.')[0]);
				})
			}

			/* 옵션 데이터 불러오기 */
			optionfactory.query({id:scope.$parent.code}).$promise.then(function(result)
			{
				/* 옵션 데이터 사이즈 설정 */
				scope.optionList = result;
				$.grep(scope.optionList,function(option)
				{
					if(option.o_field_name=='사이즈') //사이즈란 옵션이 존재할때 
					{
						var str = option.o_value;
						scope.sizeList = [];
						scope.sizeList = str.split(",");
						scope.sizeList.unshift('옵션을 선택해주세요'); //배열 첫번째 삽입
					}
				}) 

			})
			
			/* 작은 이미지 == 큰 이미지 교환 */	
			scope.imgChange = function(img)
			{ 
				scope.bImg = img;
			}

			/* 수량 증가버튼 */
			scope.quantityUp = function(total_price)
			{
				if(scope.quantity >=scope.totalQuantity)
				{
					alert("최대 "+scope.totalQuantity+"개 입니다.");
					scope.quantity = scope.totalQuantity; //(상품 총 수량)
					return false;
				}
				scope.quantity +=1; //(수량 = 수량 + 1)
				scope.price = total_price+scope.origin_price;//(총가격=총가격+단가)
	
			} 

			/* 수량 감소버튼 */ 
			scope.quantityDown = function(total_price)
			{ 
	
				if(scope.quantity <=1)
				{
					alert("최소 1개이상입니다.");
					return false;
				}
				scope.quantity -=1;
				scope.price = total_price-scope.origin_price; //(총가격= 총가격-단가)	
			}

			/* 상품 목록 */ 
			scope.itemList = function()
			{
				scope.$parent.show="list";
			}

			/* 지금 구매하기 */
			scope.nowBuy = function()
			{

			}

			/* 장바구니 추가 */
			scope.shoppingBasket =function(p_code,p_title, p_total_price, 
				                           p_buy_quantity, p_img, p_option)
			{
				if(p_option=="옵션을 선택해주세요")
				{
					alert("옵션을 선택해주세요.");
					return false;
				}
				p_option= '[옵션: '+p_option+"]";
				scope.$parent.itemNumber+=1;
				/* 장바구니 담을 object */
				scope.pocketList = {
									'code':p_code+scope.$parent.itemNumber,
								    'title':p_title,
									'origin_price':scope.origin_price,
									'total_price':p_total_price,
									'total_quantity':p_buy_quantity,
									'img':p_img,
									'option':p_option,
									'totalQuantity':scope.totalQuantity
								   }
				scope.$parent.list.push(scope.pocketList);
				scope.$parent.show="pocket";
			}
		}
	}
})

/* 상품 장바구니 PAGE */
mallDirective.directive("itemShoppingback", function(baseUrl, $document, mallfactory, optionfactory){
	return {
		restrict: 'E',
		templateUrl: baseUrl+'template/shoppingback.html',
		link: function(scope, element, attr, Ctrl)
		{

			/* 상품코드, 상품 총 가격, 총개수, 선택된 이미지, 선택 옵션*/
			scope.pocketList = scope.$parent.list;
			scope.number = 0; //초기값
			scope.price =0;
			if(scope.pocketList.length!=0)
			{
				scope.code = scope.pocketList[scope.pocketList.length-1].code;
				scope.totalQuantity = scope.pocketList[scope.pocketList.length-1].totalQuantity;
				totalItems();
				totalCal();
			}

			/* 상품 목록 */
			scope.itemList = function()
			{
				angular.forEach(scope.pocketList, function(item)
				{
					item.selected = false;
				});
				scope.$parent.show="list";
			}

			/* 모든 상품 선택 */
			scope.allCheck = function() 
			{
				if(scope.selectedAll) //모두 선택
				{
					scope.selectedAll = true;
				}
				else //모두 해제
				{
					scope.selectedAll = false;	
				}

				angular.forEach(scope.pocketList, function(item)
				{
					item.selected = scope.selectedAll;
				});
			}

			/*장바구니 수량 증가버튼 */
			scope.quantityUp = function(item)
			{
				if(item.total_quantity >=scope.totalQuantity)
				{
					alert("최대 "+scope.totalQuantity+"개 입니다.");
					item.total_quantity = scope.totalQuantity;
					return false;
				}
				item.total_quantity +=1;
				item.total_price = item.total_price+item.origin_price;//(총가격=총가격+단가)
				totalCal();
			} 
			/* 장바구니 수량 감소버튼 */ 
			scope.quantityDown = function(item)
			{
				if(item.total_quantity <=1)
				{
					alert("최소 1개이상입니다.");
					return false;
				}
				item.total_quantity -=1;
				item.total_price = item.total_price-item.origin_price; //(총가격= 총가격-단가)
				totalCal();	
			}

			/* 선택 상품 삭제 */
			scope.selectedDelete = function(item)
			{
				$("#"+item.code)[0].parentElement.remove();
				
				scope.pocketList = angular.forEach(scope.pocketList, function(value,index){
					if(value.code==item.code)
					{
						scope.pocketList.splice(index,1);	
					}
				});
				totalItems();
				totalCal();
			}

			/* 선택한 상품 자세히 보기 */
			scope.selectedDetail = function(){ 
				scope.$parent.show ="detail";
				scope.$parent.code = item_code;
			}

			/* 장바구니 비우기  */
			scope.allDelete = function()
			{
				if(scope.pocketList!=null)
				{
					scope.pocketList = angular.forEach(scope.pocketList, function(item){
						$("#"+item.code)[0].parentElement.remove();	
					})

					scope.$parent.list = []; 
					scope.pocketList = [];

					totalItems(); //상품 수량
					totalCal(); //상품 계산
				}
				else
				{
					alert("상품이 존재하지 않습니다.");
				}
			}
		
			/* 총 구매 금액 계산 */
			function totalCal()
			{
				scope.price = 0; //금액 초기화
				angular.forEach(scope.pocketList, function(item){
					scope.price+=item.total_price;
				});
			}

			/* 아이템 총 개수 */
			function totalItems() 
			{
				scope.number = scope.pocketList.length;
			}
		}
	}	
})