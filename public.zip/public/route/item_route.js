var mallApp = angular.module("MallApp", ["ngRoute",'mallDirective', "MallService" ,"ngMaterial"]);
mallApp.constant('baseUrl', '/laravel/public/');

/* config -> 환경설정. routeProvide */
mallApp.config(['$routeProvider', "baseUrl", routeProvide]);

function routeProvide($routeProvider, baseUrl)
{
    $routeProvider.when("/", {
    	
    })
}

